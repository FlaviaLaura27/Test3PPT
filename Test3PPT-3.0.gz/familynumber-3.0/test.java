package pages;
public class MIMER_01_HomePage {
  }
